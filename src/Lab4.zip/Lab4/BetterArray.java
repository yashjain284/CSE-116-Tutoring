package Lab4;
public class BetterArray 
{
	// This implementation stores integers only
	//   class must be rewritten for other types
	
	final private int INITIAL_ALLOCATION = 10;
	
	private int [] arrayBase;			// nothing allocated yet
	private int size = INITIAL_ALLOCATION;
	
	
	
	public void put(int value, int index)
		throws IndexOutOfBoundsException
	{
		if (index < 0)					// illegal index-value
		{
			throw new IndexOutOfBoundsException();
		}
		if (index >= size)				// why we're here
		{
			reAllocate(index);
		}
		arrayBase[index] = value;		// store value in new array
	}
	private void reAllocate(int index)
	{
		int oldSize = size;				// save current size for copy-loop
		while (size <= index)
		{
			size *= 2;					// try to accommodate index
		}
		int [] temporary = new int[size];
		for (int i = 0; i < oldSize; ++i)
		{
			temporary[i] = arrayBase[i];
		}
		arrayBase = temporary;			// abandon old array to GC
	}
	public int getSize()
	{
		return size;
	}
}
