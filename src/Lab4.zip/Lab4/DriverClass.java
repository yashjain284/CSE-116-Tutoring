package Lab4;

public class DriverClass {
	
	public static void main(String[] args){
		
		DoubleLinkedList array1 = new DoubleLinkedList(5);
				

		
		
		
	}
}
